const express = require("express");
const path = require("path");
const fs = require('fs');
const app = express();

//Mongoose
const mongoose = require('mongoose');
const bodyparser = require('body-parser');
mongoose.connect('mongodb://localhost/contactdb', { useNewUrlParser: true });
// main().catch(err => console.log(err));
// async function main() {
//   await mongoose.connect('mongodb://localhost:27017/test');
// }

const port = 80;

// Define mongoose schema

const contactSchema = new mongoose.Schema({
    name: String,
    phone: String,
    email: String,
    address: String,
    desc: String
});

//Compiling schema into model
const Contact = mongoose.model('Contact', contactSchema);



// EXPRESS CONFIG
app.use('/static', express.static('static')); // For serving static files
app.use(express.urlencoded());

// PUG CONFIG
app.set('views', path.join(__dirname, '/views')) //Set the views directory
app.set('view engine', 'pug'); //Set the template engine as pug
app.engine('pug', require('pug').__express)

// HTML Config

// app.get('/', function (req, res) {
//     res.sendFile('index.html',{
//         root: './views'
//     });
// });

//ENDPOINTS

//home
app.get('/', (req, res) => {
    const params = {}//'message': 'This is code academy'
    res.status(200).render('home.pug', params);
})

//services

app.get('/services', (req, res) => {
    const params = {}//'message': 'This is code academy'
    res.status(200).render('services.pug', params);
})

//About

app.get('/about', (req, res) => {
    const params = {}//'message': 'This is code academy'
    res.status(200).render('about.pug', params);
})


app.get('/contact', (req, res) => {
    const params = {}//'message': 'This is code academy'
    res.status(200).render('contact.pug', params);
})

app.post('/contact', (req, res) => {
    const myData = Contact(req.body);
    myData.save().then(() => {
        res.send("Item saved in the db");
    }).catch(() => {
        res.status(400).send("Item not saved in db");
    })
    // res.status(200).render('contact.pug');
})


// START THE SERVER
app.listen(port, () => {
    console.log(`The app started successfully using port ${port}`);
});