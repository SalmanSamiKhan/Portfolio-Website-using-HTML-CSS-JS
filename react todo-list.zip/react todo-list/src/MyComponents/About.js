import React from 'react';

export const About = () => {
  return <div>
      This is an about component
      <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere molestias ipsum sint doloribus ipsam quo quidem tempore accusantium deleniti vero? Magnam ipsam eaque optio ea? Voluptas facilis unde magnam eveniet!
      </p>
  </div>;
};
