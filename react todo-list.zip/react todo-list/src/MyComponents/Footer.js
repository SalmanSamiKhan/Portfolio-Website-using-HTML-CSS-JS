import React from 'react'

export const Footer = () => {
    
    return (
        <footer className='bg-dark text-light'>
            <p className='text-center'>
                Copyright &copy; MyTodoList.com
            </p>

        </footer>
    )
}
